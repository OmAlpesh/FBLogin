//
//  HeaderBridge.h
//  LoginSwift3Demo
//
//  Created by piyush sinroja on 19/12/16.
//  Copyright © 2016 piyush sinroja. All rights reserved.
//

#ifndef HeaderBridge_h
#define HeaderBridge_h

#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>

#endif /* HeaderBridge_h */
