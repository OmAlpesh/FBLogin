//
//  ViewController.swift
//  LoginSwift3Demo
//
//  Created by piyush sinroja on 19/12/16.
//  Copyright © 2016 piyush sinroja. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let appdelobj =  UIApplication.shared.delegate as! AppDelegate
    @IBOutlet weak var btnLogOut: UIButton!
    
    @IBOutlet weak var lblDetails: UILabel!
    @IBOutlet weak var btnFacebookLogin: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        configureFacebook()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //  MARK: configureFacebook
    func configureFacebook()
    {
        appdelobj.loginManager.loginBehavior = .native
    }
    
    //  MARK: Button Action
    @IBAction func btnLogOut(_ sender: Any) {
        FBSDKAccessToken.setCurrent(nil)
        appdelobj.loginManager.logOut()
        self.lblDetails.text = ""
    }
    
    @IBAction func btnFacebookLogin(_ sender: Any) {
        var fbLoginManager  = appdelobj.loginManager
        fbLoginManager.logIn(withReadPermissions: ["public_profile", "email", "user_friends"], from: self) { (result, error) in
            
            if (error != nil)
            {
                print("Login process error")
                
            }
            else if (result?.isCancelled)!
            {
                print("User cancelled login")
            }
            else if (error == nil)
            {
                print("Login Success")
                let fbloginresult : FBSDKLoginManagerLoginResult = result!
                if(fbloginresult.grantedPermissions.contains("email"))
                {
                    self.fetchProfile()
                   // fbLoginManager.logOut()
                    
                }
                else
                {
                    print("fjgjhkhkhk")
                }
            }
        }
    }
    
    //  MARK: FetchLogin Details
    func fetchProfile(){
        if((FBSDKAccessToken.current()) != nil){
            FBSDKGraphRequest(graphPath: "/me", parameters: ["fields" : "first_name, last_name, email, name, id, gender, picture.type(large), link, cover, age_range, relationship_status, locale"])
                .start(completionHandler:  { (connection, result, error) in
                    
                    guard let result = result as? NSDictionary,
                        let email = result["email"] as? String,
                        let strFirstName: String = result["first_name"] as? String,
                        let strLastName: String = result["last_name"] as? String,
                        let strPicture: NSDictionary = result.object(forKey: "picture") as! NSDictionary,
                        let strdata: NSDictionary  = strPicture.object(forKey: "data") as! NSDictionary,
                        let strurl: String  = strdata.object(forKey: "url") as! String,
                        let user_name = result["name"] as? String,
                        let user_gender = result["gender"] as? String,
                        let user_id_fb = result["id"]  as? String
                        else {
                            return
                    }
                    
                    self.lblDetails.text = String(describing: result)
                    
                    print(result)
                    
                })
        }
    }
    
    
    func loginButtonWillLogin(_ loginButton: FBSDKLoginButton!) -> Bool {
        return true
    }
    
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
        
    }
}

